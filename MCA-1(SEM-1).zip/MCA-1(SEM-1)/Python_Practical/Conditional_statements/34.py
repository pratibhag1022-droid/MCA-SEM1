'''
34. Write a program to check whether a year is a leap year and century year.
'''
year = int(input("Enter a year: "))

if year % 100 == 0:
    print("Century year")
else:
    print("Not a century year")

if year % 400 == 0:
    print("Leap year")
elif year % 100 == 0:
    print("Not a leap year")
elif year % 4 == 0:
    print("Leap year")
else:
    print("Not a leap year")